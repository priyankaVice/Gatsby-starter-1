import React from "react"
import { Link } from "gatsby"
import styles from "./header.module.scss"

// HeaderLink Component
const HeaderLink = props => (
    <Link className={styles.link} to={props.to}>
        {props.children}
    </Link>
)

const HomeButton = props => {
    return (
        <Link to={props.to}>
            <div className={styles.button}>{props.text}</div>
        </Link>
    )
}

// SocialButton Components
const SocialButton = props => {
    let style = ""
    let url = ""
    if (props.site === "twitter") {
        style = styles.buttonTwitter
        url = "https://twitter.com" + props.username
    } else if (props.site === "linkedin") {
        style = styles.buttonLinkedin
        url = "https://linkedin.com" + props.username
    } else if (props.site === "facebook") {
        style = styles.buttonFacebook
        url = "https://facebook.com" + props.username
    }

    return (
        <a href={url} target="_blank" rel="noopener noreferer">
            <div className={style}>{props.children}&nbsp;</div>
        </a>
    )
}

export default () => {
    return (
        <header>
            <div className={styles.container}>
                <div className={styles.row}>
                    <HomeButton to="/" text="My Gatsby blog" />
                    <SocialButton site="facebook" username="simpledev"></SocialButton>
                    <SocialButton site="linkedin" username="simpledev"></SocialButton>
                    <SocialButton site="twitter" username="simpledev"></SocialButton>
                </div>

                <div className={styles.row}>

                    <HeaderLink to="/">ARTICLES</HeaderLink>
                    <HeaderLink to="/about">ABOUT</HeaderLink>
                </div>
            </div>
        </header>
    )
}
