import React from "react";
import { Link } from "gatsby";
import styles from "./aboutbody.module.scss";
import Title from "./title";

export default () => {
    return (<div className={styles.container}>
        <Title title="About Us"></Title>
        <div className="">
            <Link to="/">Home</Link> |<Link to="/about">About me</Link>
            <p>Welcome to your new Gatsby site. Lorem posem is the text generator.</p>
            <p>Welcome to your new Gatsby site. Lorem posem is the text generator.</p>
            <p>Welcome to your new Gatsby site. Lorem posem is the text generator.</p>
            <p>Welcome to your new Gatsby site. Lorem posem is the text generator.</p>
        </div>
    </div>)
}