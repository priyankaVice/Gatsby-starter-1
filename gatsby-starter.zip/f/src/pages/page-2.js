import React from "react"

const SecondPage = () => (
  <div>Hello world</div>
)

export default SecondPage
