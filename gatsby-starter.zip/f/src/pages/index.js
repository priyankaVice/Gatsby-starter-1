import React from "react"
import Layout from "../components/layout"
import AboutBody from "../components/aboutbody";

const IndexPage = () => (
  <Layout>
    <AboutBody />
  </Layout>
)

export default IndexPage
